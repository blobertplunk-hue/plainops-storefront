Emergency Sub Plan Kit - Grade 4 - No-Prep

Thank you for purchasing this classroom resource.

WHAT IS INCLUDED
- Printable PDF packet
- Editable DOCX version
- Preview images for your reference

HOW TO USE
1. Print the student pages and substitute pages.
2. Add your classroom-specific details to the editable DOCX if desired.
3. Keep copies in a sub tub, emergency folder, or digital absence folder.
4. Use the answer key and teacher reset checklist when you return.

EDITABLE VERSION
The DOCX file can be edited in Microsoft Word. You can also upload it to Google Drive and open with Google Docs, though spacing may shift slightly after conversion.

LICENSE
Personal classroom use for one purchaser/teacher. You may customize it for your own students. Do not resell, redistribute, or post the editable file publicly. School teams, grade levels, campuses, or districts should purchase separate licenses or a multi-user license.

NOTES
No student data, logins, or external apps are required. This is a static printable/editable classroom resource.
